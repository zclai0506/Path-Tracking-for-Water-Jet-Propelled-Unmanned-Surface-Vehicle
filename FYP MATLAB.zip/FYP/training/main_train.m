%% main_train.m
% Main training script for DRL-based ILOS parameter tuning
% Trains DDPG agent to optimize lookahead distance, integral gain, and thrust
clear; close all; clc;

%% 1. Setup and Reproducibility
fprintf('=== USV Path Tracking - DRL Training ===\n\n');
% Set random seed for reproducibility
rng(42);
fprintf('Random seed set to 42 for reproducibility\n');

%% 2. Create Environment
fprintf('Creating USV tracking environment...\n');
env = USVTrackingEnv();

% Get observation and action specs
obsInfo = getObservationInfo(env);
actInfo = getActionInfo(env);

fprintf('Observation space: %d dimensions\n', obsInfo.Dimension(1));
fprintf('Action space: %d dimensions\n', actInfo.Dimension(1));
fprintf('  - Delta (lookahead): [%.1f, %.1f] m\n', actInfo.LowerLimit(1), actInfo.UpperLimit(1));
fprintf('  - k_i (integral gain): [%.3f, %.3f]\n', actInfo.LowerLimit(2), actInfo.UpperLimit(2));
fprintf('  - F_bias (thrust): [%.1f, %.1f] N\n\n', actInfo.LowerLimit(3), actInfo.UpperLimit(3));

%% 3. Create DDPG Agent Networks
fprintf('Building DDPG agent networks...\n');

% ========== ACTOR NETWORK ==========
% Maps observations to actions: obs(8) → action(3)
actorLayers = [
    featureInputLayer(obsInfo.Dimension(1), 'Normalization', 'none', 'Name', 'observation')
    fullyConnectedLayer(128, 'Name', 'fc1')
    reluLayer('Name', 'relu1')
    fullyConnectedLayer(64, 'Name', 'fc2')
    reluLayer('Name', 'relu2')
    fullyConnectedLayer(actInfo.Dimension(1), 'Name', 'fc_out')
    tanhLayer('Name', 'tanh')
    scalingLayer('Name', 'scaling', ...
                 'Scale', (actInfo.UpperLimit - actInfo.LowerLimit)/2, ...
                 'Bias', (actInfo.UpperLimit + actInfo.LowerLimit)/2)
];
actor = rlContinuousDeterministicActor(actorLayers, obsInfo, actInfo);
fprintf('✓ Actor: obs(8) → FC(128) → FC(64) → action(3)\n');

% ========== CRITIC NETWORK ==========
% Maps [observation, action] → Q-value
% Uses separate input paths that are merged

% Observation path
obsPath = [
    featureInputLayer(obsInfo.Dimension(1), 'Normalization', 'none', 'Name', 'obs_input')
    fullyConnectedLayer(128, 'Name', 'obs_fc')
];

% Action path
actPath = [
    featureInputLayer(actInfo.Dimension(1), 'Normalization', 'none', 'Name', 'act_input')
    fullyConnectedLayer(128, 'Name', 'act_fc')
];

% Common path after merging
commonPath = [
    additionLayer(2, 'Name', 'merge')
    reluLayer('Name', 'relu1')
    fullyConnectedLayer(64, 'Name', 'fc2')
    reluLayer('Name', 'relu2')
    fullyConnectedLayer(1, 'Name', 'q_output')
];

% Assemble critic network
criticGraph = layerGraph(obsPath);
criticGraph = addLayers(criticGraph, actPath);
criticGraph = addLayers(criticGraph, commonPath);
criticGraph = connectLayers(criticGraph, 'obs_fc', 'merge/in1');
criticGraph = connectLayers(criticGraph, 'act_fc', 'merge/in2');

% Create critic representation
critic = rlQValueFunction(criticGraph, obsInfo, actInfo, ...
    'ObservationInputNames', 'obs_input', ...
    'ActionInputNames', 'act_input');
fprintf('✓ Critic: [obs(8)+act(3)] → FC(128+128) → FC(64) → Q(1)\n\n');

%% 4. Configure DDPG Agent
fprintf('Configuring DDPG agent options...\n');
agentOpts = rlDDPGAgentOptions(...
    'SampleTime', env.dt, ...
    'TargetSmoothFactor', 1e-3, ...
    'ExperienceBufferLength', 10000, ...
    'MiniBatchSize', 64, ...
    'DiscountFactor', 0.99);

% Actor learning parameters
agentOpts.ActorOptimizerOptions.LearnRate = 1e-4;
agentOpts.ActorOptimizerOptions.GradientThreshold = 1;

% Critic learning parameters
agentOpts.CriticOptimizerOptions.LearnRate = 1e-3;
agentOpts.CriticOptimizerOptions.GradientThreshold = 1;

% Exploration noise (Ornstein-Uhlenbeck process)
agentOpts.NoiseOptions.Variance = 0.3^2;
agentOpts.NoiseOptions.VarianceDecayRate = 1e-5;
agentOpts.NoiseOptions.VarianceMin = 0.05^2;

% Create DDPG agent
agent = rlDDPGAgent(actor, critic, agentOpts);
fprintf('Learning rates - Actor: %.0e | Critic: %.0e\n', ...
    agentOpts.ActorOptimizerOptions.LearnRate, ...
    agentOpts.CriticOptimizerOptions.LearnRate);
fprintf('Replay buffer: %d samples | Batch size: %d\n', ...
    agentOpts.ExperienceBufferLength, agentOpts.MiniBatchSize);
fprintf('Exploration noise: σ² = %.2f → %.2f (decay: %.0e)\n\n', ...
    agentOpts.NoiseOptions.Variance, ...
    agentOpts.NoiseOptions.VarianceMin, ...
    agentOpts.NoiseOptions.VarianceDecayRate);

%% 5. Training Configuration
fprintf('Setting up training parameters...\n');
trainOpts = rlTrainingOptions(...
    'MaxEpisodes', 100, ...
    'MaxStepsPerEpisode', 1200, ...
    'ScoreAveragingWindowLength', 20, ...
    'StopTrainingCriteria', 'AverageReward', ...
    'StopTrainingValue', -50, ...
    'SaveAgentCriteria', 'EpisodeReward', ...
    'SaveAgentDirectory', 'saved_agents', ...
    'SaveAgentValue', -100, ...
    'Verbose', true, ...
    'Plots', 'training-progress');

fprintf('Episodes: %d (max %d steps each = %.1fs)\n', ...
    trainOpts.MaxEpisodes, ...
    trainOpts.MaxStepsPerEpisode, ...
    trainOpts.MaxStepsPerEpisode * env.dt);
fprintf('Success criterion: Avg reward > %.1f\n', trainOpts.StopTrainingValue);
fprintf('Agent auto-save: Episode reward > %.1f\n\n', trainOpts.SaveAgentValue);

%% 6. Train the Agent
fprintf('====================================\n');
fprintf('Starting DDPG training...\n');
fprintf('Press Ctrl+C to interrupt\n');
fprintf('====================================\n\n');

tic;
trainingStats = train(agent, env, trainOpts);
trainingTime = toc;

fprintf('\n====================================\n');
fprintf('Training Complete!\n');
fprintf('====================================\n');
fprintf('Total time: %.2f minutes\n', trainingTime/60);
fprintf('Episodes completed: %d\n', length(trainingStats.EpisodeIndex));
fprintf('Final average reward: %.2f\n', trainingStats.AverageReward(end));

if trainingStats.AverageReward(end) > trainOpts.StopTrainingValue
    fprintf('✓ Training SUCCESS - Target achieved!\n');
else
    fprintf('⚠ Training stopped before target\n');
end

%% 7. Save Trained Agent and Export to ONNX for ROS 2
if ~exist('saved_agents', 'dir')
    mkdir('saved_agents');
end
timestamp = datestr(now, 'yyyymmdd_HHMMSS');

% --- 7.1 Save Native MATLAB Configurations ---
save_filename = sprintf('saved_agents/trained_drl_ilos_%s.mat', timestamp);
save(save_filename, 'agent', 'trainingStats', 'env', 'agentOpts', 'trainOpts');
fprintf('\n✓ Native MATLAB Agent saved: %s\n', save_filename);
save('saved_agents/trained_drl_ilos_latest.mat', 'agent', 'trainingStats', 'env');
fprintf('✓ Latest version: saved_agents/trained_drl_ilos_latest.mat\n');

% --- 7.2 Extract Actor Weights for Python/NumPy ---
fprintf('Extracting Actor weights to .mat for Python...\n');

% 1. Get the actor object and the internal network
actorObj = getActor(agent);
net = getModel(actorObj);

% 2. Extract weights and biases by Layer Name
% This is much safer than using getLearnableParameters
weights = struct();

% FC1 Layer (index 2 in your actorLayers)
weights.fc1_w = net.Layers(2).Weights;
weights.fc1_b = net.Layers(2).Bias;

% FC2 Layer (index 4 in your actorLayers)
weights.fc2_w = net.Layers(4).Weights;
weights.fc2_b = net.Layers(4).Bias;

% FC_OUT Layer (index 6 in your actorLayers)
weights.fc_out_w = net.Layers(6).Weights;
weights.fc_out_b = net.Layers(6).Bias;

% 3. Save to a .mat file
save('saved_agents/actor_weights.mat', '-struct', 'weights');
fprintf('✓ Weights exported to saved_agents/actor_weights.mat\n');

%% 8. Post-Training Validation
fprintf('\n====================================\n');
fprintf('Running Validation Tests\n');
fprintf('====================================\n');

% Create results directory
results_dir = '../data/preliminary_results';
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end

test_results = struct();

% Test 1: Vertical Straight Path
fprintf('\n[1/3] Vertical Straight path (200m)...\n');
straight_data = runValidationTest(env, agent, 'straight');
test_results.straight = straight_data;
printTestMetrics(straight_data);

% Test 2: Clockwise Rectangle
fprintf('\n[2/3] Clockwise Rectangular Path (100x50m)...\n');
rectangle_data = runValidationTest(env, agent, 'rectangle');
test_results.rectangle = rectangle_data;
printTestMetrics(rectangle_data);

% Test 3: Clockwise Circle
fprintf('\n[3/3] Clockwise Circular Path (Radius=50m)...\n');
circle_data = runValidationTest(env, agent, 'circle');
test_results.circle = circle_data;
printTestMetrics(circle_data);

%% 9. Generate Validation Plots
fprintf('\n====================================\n');
fprintf('Generating validation plots...\n');

fig = figure('Position', [100, 100, 1400, 900], 'Color', 'w');

% ===== Row 1: Trajectories =====
subplot(2, 3, 1);
plotTrajectory(straight_data, 'Vertical Straight Path');
subplot(2, 3, 2);
plotTrajectory(rectangle_data, 'Clockwise Rectangle Path');
subplot(2, 3, 3);
plotTrajectory(circle_data, 'Clockwise Circular Path');

% ===== Row 2: Cross-Track Errors =====
subplot(2, 3, 4);
plotError(straight_data, 'Vertical Path Error');
subplot(2, 3, 5);
plotError(rectangle_data, 'Rectangle Path Error');
subplot(2, 3, 6);
plotError(circle_data, 'Circular Path Error');

sgtitle('DRL-ILOS Validation: Multi-Path Performance', ...
    'FontSize', 14, 'FontWeight', 'bold');

% Save validation figure
validation_fig = fullfile(results_dir, 'validation_plots.png');
exportgraphics(fig, validation_fig, 'Resolution', 300);
fprintf('✓ Plots saved: %s\n', validation_fig);

%% 10. Save All Results
results_file = fullfile(results_dir, 'training_performance.mat');
save(results_file, 'trainingStats', 'test_results', 'agentOpts', ...
     'trainOpts', 'trainingTime');
fprintf('✓ Results saved: %s\n', results_file);
fprintf('\n====================================\n');
fprintf('All Tasks Complete!\n');
fprintf('====================================\n');
fprintf('Next step: Run visualize_results.m for detailed comparison\n\n');

%% ========== HELPER FUNCTIONS ==========

function data = runValidationTest(env, agent, path_type)
    % Run a single validation test on specified path type
    
    % Reset environment
    obs = reset(env);
    
    % Preallocate storage
    max_steps = 2500;
    data = struct();
    data.time = zeros(max_steps, 1);
    data.x = zeros(max_steps, 1);
    data.y = zeros(max_steps, 1);
    data.x_ref = zeros(max_steps, 1);
    data.y_ref = zeros(max_steps, 1);
    data.e = zeros(max_steps, 1);
    data.psi = zeros(max_steps, 1);
    data.u = zeros(max_steps, 1);
    data.Delta = zeros(max_steps, 1);
    data.k_i = zeros(max_steps, 1);
    data.F_bias = zeros(max_steps, 1);
    
    % Waypoint logic for Rectangle
    WP = [0,0; 0,100; 50,100; 50,0; 0,0];
    current_wp = 1;
    
    % Run simulation
    for k = 1:max_steps
        % Get current position
        x_current = env.State(1);
        y_current = env.State(2);
        
        % Update path based on type
        switch path_type
            case 'straight'
                % Vertical line up the Y-axis
                env.x_path = 0;
                env.y_path = 0;
                env.chi_path = pi/2; % Due North
                data.x_ref(k) = 0;
                data.y_ref(k) = y_current;
                
            case 'rectangle'
                % Check if close to next waypoint to switch segment
                p2 = WP(current_wp+1, :);
                dist_to_p2 = norm([x_current, y_current] - p2);
                if dist_to_p2 < 5.0 && current_wp < 4
                    current_wp = current_wp + 1;
                end
                p1 = WP(current_wp, :); 
                p2 = WP(current_wp+1, :);
                
                % Update environment path
                env.x_path = p1(1); 
                env.y_path = p1(2);
                env.chi_path = atan2(p2(2)-p1(2), p2(1)-p1(1));
                
                % Project current position onto segment for plotting
                v1 = [x_current - p1(1), y_current - p1(2)];
                v2 = [p2(1) - p1(1), p2(2) - p1(2)];
                v2_norm = v2 / norm(v2);
                proj = p1 + dot(v1, v2_norm) * v2_norm;
                data.x_ref(k) = proj(1); 
                data.y_ref(k) = proj(2);
                
            case 'circle'
                % Center at (50,0), Radius 50. Starts at (0,0) facing North.
                xc = 50; yc = 0; R = 50;
                theta = atan2(y_current - yc, x_current - xc);
                
                % Closest point on circle
                data.x_ref(k) = xc + R * cos(theta);
                data.y_ref(k) = yc + R * sin(theta);
                
                % Assign to environment
                env.x_path = data.x_ref(k);
                env.y_path = data.y_ref(k);
                env.chi_path = wrapToPi(theta - pi/2); % -pi/2 for Clockwise tangent
        end
        
        % Get action from trained agent
        [action, ~] = getAction(agent, obs);
        if iscell(action)
            action = action{1}; 
        end
        action = action(:);
        
        % Step environment
        [obs, ~, ~, ~] = env.step(action);
        done = false;
        
        % Check if episode should terminate
        if strcmp(path_type, 'straight') && env.State(2) >= 200
            done = true;
        elseif strcmp(path_type, 'rectangle') && current_wp == 4 && dist_to_p2 < 5.0
            done = true;
        elseif k >= max_steps
            done = true;
        end
        if strcmp(path_type, 'circle') && env.State(1) < 2.0 && env.State(2) > -2.0 && env.State(2) < 2.0 && k > 200
        done = true;
        end
        
        % Store data
        data.time(k) = env.CurrentTime;
        data.x(k) = env.State(1);
        data.y(k) = env.State(2);
        
        % Calculate cross-track error manually
        data.e(k) = calculateCrossTrackError(env, data.x_ref(k), data.y_ref(k));
        
        data.psi(k) = env.State(3);
        data.u(k) = env.State(4);
        data.Delta(k) = action(1);
        data.k_i(k) = action(2);
        data.F_bias(k) = action(3);
        
        if done
            data = trimData(data, k);
            break;
        end
    end
end

function data = trimData(data, final_step)
    % Trim preallocated arrays to actual length
    fields = fieldnames(data);
    for i = 1:length(fields)
        data.(fields{i}) = data.(fields{i})(1:final_step);
    end
end

function printTestMetrics(data)
    fprintf('  Mean |e|: %.3f m | Max |e|: %.3f m | Final |e|: %.3f m\n', ...
        mean(abs(data.e)), max(abs(data.e)), abs(data.e(end)));
    fprintf('  RMS(e): %.3f m | Settling time: %.1f s\n', ...
        sqrt(mean(data.e.^2)), findSettlingTime(data.time, data.e));
end

function t_settle = findSettlingTime(time, error)
    threshold = 0.02 * abs(error(1));
    if threshold == 0 || isnan(threshold)
        threshold = 0.5;  % Default threshold if starting on the line
    end
    idx = find(abs(error) <= threshold, 1, 'first');
    if ~isempty(idx)
        t_settle = time(idx);
    else
        t_settle = inf;
    end
end

function plotTrajectory(data, title_str)
    hold on; grid on; box on;
    plot(data.x_ref, data.y_ref, 'r--', 'LineWidth', 2, 'DisplayName', 'Reference');
    plot(data.x, data.y, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Actual');
    plot(data.x(1), data.y(1), 'go', 'MarkerSize', 8, 'MarkerFaceColor', 'g', ...
        'DisplayName', 'Start');
    plot(data.x(end), data.y(end), 'rs', 'MarkerSize', 8, 'MarkerFaceColor', 'r', ...
        'DisplayName', 'End');
    xlabel('X Position [m]', 'FontSize', 10);
    ylabel('Y Position [m]', 'FontSize', 10);
    title(title_str, 'FontSize', 11, 'FontWeight', 'bold');
    legend('Location', 'best', 'FontSize', 8);
    axis equal;
end

function plotError(data, title_str)
    hold on; grid on; box on;
    plot(data.time, data.e, 'b-', 'LineWidth', 1.5);
    yline(0, 'k--', 'LineWidth', 1);
    xlabel('Time [s]', 'FontSize', 10);
    ylabel('Cross-Track Error [m]', 'FontSize', 10);
    title(title_str, 'FontSize', 11, 'FontWeight', 'bold');
    max_e = max(abs(data.e));
    if max_e > 0
        ylim([-max_e*1.2, max_e*1.2]);
    end
end

function e = calculateCrossTrackError(env, x_ref, y_ref)
    x_pos = env.State(1);
    y_pos = env.State(2);
    psi_path = env.chi_path;
    e = -(x_pos - x_ref) * sin(psi_path) + (y_pos - y_ref) * cos(psi_path);
end