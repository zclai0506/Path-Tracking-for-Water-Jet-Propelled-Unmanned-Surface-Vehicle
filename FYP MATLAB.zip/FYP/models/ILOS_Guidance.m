function [psi_d, e, e_int_new] = ILOS_Guidance(x, y, psi, x_path, y_path, chi_path, e_int, Delta, k_i, dt)
    % ILOS_Guidance - Integral Line-of-Sight guidance law for path following
    % 
    % Computes desired heading to follow a straight-line path segment with
    % integral action to compensate for drift (e.g., ocean currents)
    %
    % Inputs:
    %   x, y      - Current position [m]
    %   psi       - Current heading [rad] (not used in standard ILOS but included for interface)
    %   x_path    - Path waypoint x-coordinate [m]
    %   y_path    - Path waypoint y-coordinate [m]
    %   chi_path  - Path course angle [rad]
    %   e_int     - Integral of cross-track error [m⋅s]
    %   Delta     - Look-ahead distance [m] (tunable by DRL)
    %   k_i       - Integral gain (tunable by DRL)
    %   dt        - Time step [s]
    %
    % Outputs:
    %   psi_d     - Desired heading [rad]
    %   e         - Cross-track error [m]
    %   e_int_new - Updated integral of cross-track error [m⋅s]
    
    % Cross-track error (perpendicular distance from vehicle to path)
    % Positive e means vehicle is to the right of the path
    e = -(x - x_path) * sin(chi_path) + (y - y_path) * cos(chi_path);
    
    % Update integral of cross-track error
    e_int_new = e_int + e * dt;
    
    % ADDED: Anti-windup limit for cross-track integral
    % Prevents massive overshoot if the USV starts far from the path.
    % A good rule of thumb is to limit the integral influence to not exceed
    % the lookahead distance Delta, or a tuned threshold.
    e_int_max = 50.0; % Adjust this threshold based on your simulation scale
    e_int_new = max(-e_int_max, min(e_int_new, e_int_max));
    
    % Integral LOS guidance angle
    chi_los = chi_path - atan((e + k_i * e_int_new) / Delta);
    
    % Desired heading (align with LOS angle)
    psi_d = chi_los;
    
    % Wrap to [-pi, pi]
    psi_d = wrapToPi(psi_d);
end