classdef USVModel
    % USVModel - 3-DOF USV dynamics based on Fossen equations for Pro Boat Sonicwake 48
    % Implements calibrated surge, sway, and yaw dynamics with a plastic 40mm waterjet
    
    properties
        % --- Rigid Body Physical Properties ---
        m = 7.5;         % Total Mass [kg] (Hull + 40mm plastic jet + payload electronics)
        I_z = 0.95;      % Yaw moment of inertia [kg·m²] (Calibrated for 1.2m Deep-V hull)
        
        % --- Calibrated Added Mass Matrices (Fossen Formulation) ---
        X_u_dot = -0.65; % Surge added mass [kg] (~8-10% of total mass for planing hulls)
        Y_v_dot = -3.80; % Sway added mass [kg] (High cross-sectional wetted hull area resistance)
        N_r_dot = -0.45; % Yaw added mass [kg·m²]
        
        % --- Calibrated Hydrodynamic Damping (Deep-V Planing Hull Profiles) ---
        % Linear damping forces (Dominant at lower speeds)
        X_u = -1.50;     % Surge linear damping [kg/s]
        Y_v = -12.00;    % Sway linear damping [kg/s] (Enhanced by hull strakes and turn fins)
        Y_r = -0.80;     % Sway-yaw coupled damping [kg·m/s]
        N_v = -0.80;     % Yaw-sway coupled damping [kg·m/s]
        N_r = -2.50;     % Yaw linear damping [kg·m²/s]
        
        % Quadratic damping forces (Dominant at high operational cruise speeds)
        X_uu = -2.40;    % Surge quadratic damping [kg/m]
        Y_vv = -28.50;   % Sway quadratic damping [kg/m]
        N_rr = -4.80;    % Yaw quadratic damping [kg·m²]
        
        % --- Standard Plastic 40mm Waterjet Propulsion System ---
        x_jet = -0.58;   % Jet x-position (Transom stern mount distance from CoG) [m]
        y_jet = 0;       % Jet y-position (Centerline placement) [m]
        F_jet_max = 24.5;% Maximum Thrust [N] (Calibrated for plastic RC jet producing ~2.5kg force)
        delta_max = 30;  % Maximum nozzle deflection angle [deg] (Standard steering throw limit)
        
        % Ocean current environmental disturbances
        V_current = 0;   % Current speed [m/s]
        beta_current = 0;% Current direction [rad]
    end
    
    methods
        function obj = USVModel()
            % Constructor - initializes USV model with default calibrated properties
        end
        
        function [state_new, velocities] = update(obj, state, F_jet, delta, dt)
            % UPDATE - Integrate rigid-body dynamics using Runge-Kutta 4th Order (RK4)
            % Inputs:
            %   state - [x, y, psi, u, v, r]' current state vector
            %   F_jet - Thrust force [N]
            %   delta - Nozzle deflection angle [deg]
            %   dt    - Time step size [s]
            
            % Enforce strict physical saturation limits on actuator capabilities
            F_jet = max(0, min(F_jet, obj.F_jet_max));
            delta = max(-obj.delta_max, min(delta, obj.delta_max));
            
            % RK4 Numerical Integration Steps
            k1 = obj.dynamics(state, F_jet, delta);
            k2 = obj.dynamics(state + 0.5*dt*k1, F_jet, delta);
            k3 = obj.dynamics(state + 0.5*dt*k2, F_jet, delta);
            k4 = obj.dynamics(state + dt*k3, F_jet, delta);
            
            state_new = state + (dt/6) * (k1 + 2*k2 + 2*k3 + k4);
            
            % Normalize heading tracking window to [-pi, pi]
            state_new(3) = wrapToPi(state_new(3));
            
            % Extract body velocities
            velocities = state_new(4:6);
        end
        
        function state_dot = dynamics(obj, state, F_jet, delta)
            % DYNAMICS - Compute high-fidelity state derivatives via Fossen Marine equations
            
            % Extract explicit state vectors
            psi = state(3);
            u = state(4);
            v = state(5);
            r = state(6);
            
            % Map out relative velocities accounting for environmental currents
            u_c = obj.V_current * cos(obj.beta_current);
            v_c = obj.V_current * sin(obj.beta_current);
            
            u_r = u - u_c;
            v_r = v - v_c;
            
            % Hydrodynamic Mass Matrix Solver (Rigid Body Mass + Added Fluid Mass)
            M11 = obj.m - obj.X_u_dot;
            M22 = obj.m - obj.Y_v_dot;
            M33 = obj.I_z - obj.N_r_dot;
            
            % Hydrodynamic Coriolis and Centripetal Effects
            C13 = -M22 * v_r;
            C23 = M11 * u_r;
            
            % Unified Non-Linear Hydrodynamic Damping Vectors (Linear + Quadratic Components)
            X_damping = obj.X_u * u_r + obj.X_uu * abs(u_r) * u_r;
            Y_damping = obj.Y_v * v_r + obj.Y_r * r + obj.Y_vv * abs(v_r) * v_r;
            N_damping = obj.N_v * v_r + obj.N_r * r + obj.N_rr * abs(r) * r;
            
            % Actuator Steering Transformation Coordinates
            % Note: Deflection sign is kept inverted to map guidance vector logic to steering linkages
            delta_rad = deg2rad(-delta);
            
            tau_X = F_jet * cos(delta_rad);
            tau_Y = F_jet * sin(delta_rad);
            tau_N = obj.x_jet * F_jet * sin(delta_rad);
            
            % Acceleration State Space Solvers (Fossen Equation System)
            u_dot = (tau_X - C13 * r + X_damping) / M11;
            v_dot = (tau_Y - C23 * r + Y_damping) / M22;
            
            % Includes Munk Moment ((M11 - M22)*u_r*v_r) to replicate realistic yaw instability
            r_dot = (tau_N + (M11 - M22) * u_r * v_r + N_damping) / M33;
            
            % Kinematic Translation Matrix (Transforms Body-Frame Velocities to Inertial World Frame)
            x_dot = u * cos(psi) - v * sin(psi);
            y_dot = u * sin(psi) + v * cos(psi);
            psi_dot = r;
            
            % Compile final time derivative vector
            state_dot = [x_dot; y_dot; psi_dot; u_dot; v_dot; r_dot];
        end
        
        function obj = setCurrentDisturbance(obj, V_current, beta_current)
            % SETCURRENTDISTURBANCE - Interject environmental disturbances
            obj.V_current = V_current;
            obj.beta_current = beta_current;
        end
        
        function isDynamic = checkSteerability(obj, u, delta)
            % CHECKSTEERABILITY - Safety barrier verifying waterjet dynamic helm control
            if u < 0.25 && abs(delta) > 15
                isDynamic = false;
            else
                isDynamic = true;
            end
        end
        
        function displayParameters(obj)
            % DISPLAYPARAMETERS - Clean console output print statement
            fprintf('\n=== Calibrated Sonicwake 48 USV Model Parameters ===\n');
            fprintf('Vessel Mass: %.2f kg\n', obj.m);
            fprintf('Yaw Inertia: %.3f kg⋅m²\n', obj.I_z);
            fprintf('\nHydrodynamic Added Mass:\n');
            fprintf('  X_u_dot: %.2f kg | Y_v_dot: %.2f kg | N_r_dot: %.3f kg⋅m²\n', obj.X_u_dot, obj.Y_v_dot, obj.N_r_dot);
            fprintf('\nPropulsion System (Standard Plastic 40mm Jet Pump):\n');
            fprintf('  Transom Placement Lever: %.2f m\n', obj.x_jet);
            fprintf('  Max Plastic Thrust Output: %.1f N (~2.5 kg Bollard Pull)\n', obj.F_jet_max);
            fprintf('  Max Steering Nozzle Deflection: ±%.1f°\n', obj.delta_max);
            fprintf('====================================================\n\n');
        end
    end
end