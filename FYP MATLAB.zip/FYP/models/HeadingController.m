classdef HeadingController
    % HeadingController - PID controller for USV heading with coupled thrust-steering
    % Designed for single plastic waterjet propulsion system (Pro Boat Sonicwake 48)
    
    properties
        % PID gains
        Kp = 0.8;      % Proportional gain
        Ki = 0.05;     % Integral gain
        Kd = 0.3;      % Derivative gain
        
        % Integral windup limits
        integral_limit = deg2rad(20);  % ±20° in radians
        
        % Internal state
        e_int = 0;     % Integral of heading error
        
        % Saturation limits (Calibrated for standard plastic 40mm jet pump parameters)
        delta_max = 30;      % Maximum nozzle deflection [deg] (Synced with USVModel)
        F_jet_max = 24.5;    % Maximum thrust [N] (Synced with 2.5kg plastic jet capacity)
        F_jet_min = 0;       % Minimum thrust [N]
        F_steering_min = 6.0;% Minimum thrust for steering [N] (Lowered to fit 24.5N envelope)
        
        % Large error threshold
        large_error_threshold = deg2rad(10);  % 10° threshold
    end
    
    methods
        function obj = HeadingController(Kp, Ki, Kd)
            % Constructor - Initialize controller with optional custom gains
            if nargin >= 1
                obj.Kp = Kp;
            end
            if nargin >= 2
                obj.Ki = Ki;
            end
            if nargin >= 3
                obj.Kd = Kd;
            end
        end
        
        function [F_jet, delta, obj] = compute(obj, psi_desired, psi_current, r_current, u_current, F_bias, dt)
            % COMPUTE - Calculate thrust and nozzle deflection commands
            
            % Heading error (wrapped to [-pi, pi])
            e_psi = wrapToPi(psi_desired - psi_current);
            
            % Update integral with anti-windup
            obj.e_int = obj.e_int + e_psi * dt;
            obj.e_int = max(-obj.integral_limit, min(obj.e_int, obj.integral_limit));
            
            % PID control law for nozzle deflection
            % D term: derivative approximated by negative yaw rate to avoid derivative kick
            delta_rad = obj.Kp * e_psi + obj.Ki * obj.e_int + obj.Kd * (-r_current);
            
            % Convert to degrees and saturate
            delta = rad2deg(delta_rad);
            delta = max(-obj.delta_max, min(delta, obj.delta_max));
            
            % Base thrust from bias
            F_jet = F_bias;
            
            % Minimum steering thrust enforcement
            % If large heading error, ensure sufficient thrust for effective steering
            if abs(e_psi) > obj.large_error_threshold
                F_jet = max(F_jet, obj.F_steering_min);
            end
            
            % Saturate thrust within true physical bounds
            F_jet = max(obj.F_jet_min, min(F_jet, obj.F_jet_max));
        end
        
        function obj = reset(obj)
            % RESET - Reset integral state
            obj.e_int = 0;
        end
        
        function obj = setGains(obj, Kp, Ki, Kd)
            % SETGAINS - Update PID gains
            obj.Kp = Kp;
            obj.Ki = Ki;
            obj.Kd = Kd;
        end
        
        function displayGains(obj)
            % DISPLAYGAINS - Display current controller parameters
            fprintf('\n=== Heading Controller Parameters ===\n');
            fprintf('PID Gains:\n');
            fprintf('  Kp: %.2f\n', obj.Kp);
            fprintf('  Ki: %.3f\n', obj.Ki);
            fprintf('  Kd: %.2f\n', obj.Kd);
            fprintf('Integral Limit: ±%.1f°\n', rad2deg(obj.integral_limit));
            fprintf('Large Error Threshold: %.1f°\n', rad2deg(obj.large_error_threshold));
            fprintf('Minimum Steering Thrust: %.1f N\n', obj.F_steering_min);
            fprintf('Maximum Allowed Thrust: %.1f N\n', obj.F_jet_max);
            fprintf('===================================\n\n');
        end
    end
end