function visualize_results()
    % Polished visualize_results.m
    % Implements proximity-based completion and sharper waypoint tracking
    
    fprintf('=== RL-ILOS Performance Comparison ===\n\n');
    
    %% 1. Load Agent
    agent_dir = 'saved_agents';
    agent_file = fullfile(agent_dir, 'trained_drl_ilos_latest.mat');
    
    if ~exist(agent_file, 'file')
        error('Latest agent not found! Make sure training has run at least 1 episode.');
    end
    
    fprintf('Loading fresh agent: %s\n', agent_file);
    load(agent_file, 'agent');
    fprintf('✓ Agent loaded\n\n');
   
    %% 2. Parameters & Simulation Variables
    baseline_params.Delta = 20;      
    baseline_params.k_i = 0.001;      
    baseline_params.F_bias = 15;     % Calibrated baseline thrust bias for plastic waterjet
    
    dt = 0.05;      
    t_max = 300;    % Extended time limit to ensure realistic plastic thruster velocities finish loops
    t = 0:dt:t_max;
    
    %% 3. Path Scenarios
    path_straight.type = 'straight';
    path_straight.x_goal = 0; path_straight.y_goal = 200;
    
    path_rect.type = 'rectangle';
    path_rect.WP = [0,0; 0,100; 50,100; 50,0; 0,0];
    
    path_circle.type = 'circle';
    path_circle.xc = 50; path_circle.yc = 0; path_circle.R = 50;
    path_circle.x_goal = 0; path_circle.y_goal = 0;
    
    %% 4. Run Simulations
    fprintf('Running simulations with smart termination logic...\n');
    res_s_rl = simulate_controller(agent, path_straight, t, dt, 'RL', baseline_params);
    res_s_bl = simulate_controller(baseline_params, path_straight, t, dt, 'ILOS', baseline_params);
    res_r_rl = simulate_controller(agent, path_rect, t, dt, 'RL', baseline_params);
    res_r_bl = simulate_controller(baseline_params, path_rect, t, dt, 'ILOS', baseline_params);
    res_c_rl = simulate_controller(agent, path_circle, t, dt, 'RL', baseline_params);
    res_c_bl = simulate_controller(baseline_params, path_circle, t, dt, 'ILOS', baseline_params);
    
    %% 5. Visualization Matrix (3 Columns: DRL | ILOS | Overlaid Error)
    fig = figure('Position', [50, 50, 1450, 920], 'Color', 'w');
    
    % --- Row 1: Straight Path ---
    subplot(3,3,1); plot_single_trajectory(res_s_rl, path_straight, 'b-', t); title('DRL Straight Trajectory');
    subplot(3,3,2); plot_single_trajectory(res_s_bl, path_straight, 'r-', t); title('ILOS Straight Trajectory');
    subplot(3,3,3); plot_error_comparison(res_s_rl, res_s_bl, t); title('Straight Cross-Track Error');
    
    % --- Row 2: Rectangle Path ---
    subplot(3,3,4); plot_single_trajectory(res_r_rl, path_rect, 'b-', t); title('DRL Rectangle Trajectory');
    subplot(3,3,5); plot_single_trajectory(res_r_bl, path_rect, 'r-', t); title('ILOS Rectangle Trajectory');
    subplot(3,3,6); plot_error_comparison(res_r_rl, res_r_bl, t); title('Rectangle Cross-Track Error');
    
    % --- Row 3: Circle Path ---
    subplot(3,3,7); plot_single_trajectory(res_c_rl, path_circle, 'b-', t); title('DRL Circular Trajectory');
    subplot(3,3,8); plot_single_trajectory(res_c_bl, path_circle, 'r-', t); title('ILOS Circular Trajectory');
    subplot(3,3,9); plot_error_comparison(res_c_rl, res_c_bl, t); title('Circular Cross-Track Error');
    
    sgtitle('Path Tracking Performance Analysis: DRL-ILOS vs. Classical ILOS', 'FontWeight', 'bold', 'FontSize', 14);
    fprintf('✓ Visualization Generated\n');
end

%% --- Simulation Logic ---
function res = simulate_controller(ctrl, path, t, dt, type, baseline_params)
    N = length(t);
    vsl = USVModel();
    pid = HeadingController();
    
    state = [0; 0; pi/2; 1.0; 0; 0]; 
    res = struct('x',nan(1,N),'y',nan(1,N),'psi',nan(1,N),'e',nan(1,N),'delta',nan(1,N),'F_jet',nan(1,N),'Delta',nan(1,N),'k_i',nan(1,N),'F_bias',nan(1,N));
    e_int = 0; wp = 2; 
    
    for i = 1:N
        x_curr   = state(1);
        y_curr   = state(2);
        psi_curr = state(3);
        u_curr   = state(4);
        r_current= state(6);
        
        res.x(i) = x_curr; 
        res.y(i) = y_curr; 
        res.psi(i) = psi_curr;
        
        [x_p, y_p, chi_p, wp] = get_ref(path, x_curr, y_curr, wp);
        
        % Calculate cross-track error
        e_obs = -(x_curr - x_p) * sin(chi_p) + (y_curr - y_p) * cos(chi_p);
        
        % Compute dynamic target goals based on path structure
        if strcmp(path.type, 'rectangle')
            WP = path.WP;
            dist_to_waypoint = sqrt((x_curr - WP(wp, 1))^2 + (y_curr - WP(wp, 2))^2);
            x_final = WP(end,1); y_final = WP(end,2);
        elseif strcmp(path.type, 'circle')
            dist_to_waypoint = sqrt((x_curr - path.x_goal)^2 + (y_curr - path.y_goal)^2);
            x_final = path.x_goal; y_final = path.y_goal;
        else
            dist_to_waypoint = sqrt((x_curr - path.x_goal)^2 + (y_curr - path.y_goal)^2);
            x_final = path.x_goal; y_final = path.y_goal;
        end
        
        if strcmp(type, 'RL')
            % Curvature input to observation vector
            if strcmp(path.type, 'circle')
                kappa = 1 / path.R;
            else
                kappa = 0;
            end
            obs = [e_obs; wrapToPi(chi_p - psi_curr); e_int; state(4); state(5); state(6); kappa; dist_to_waypoint];
            act = getAction(ctrl, obs); 
            if iscell(act), act = act{1}; end
            D  = act(1); ki = act(2); Fb = act(3);
        else
            D  = ctrl.Delta; ki = ctrl.k_i; Fb = ctrl.F_bias;
        end
        
        [psi_d, e, e_int] = ILOS_Guidance(x_curr, y_curr, psi_curr, x_p, y_p, chi_p, e_int, D, ki, dt);
        res.e(i) = e;
        
        [F_jet, delta_deg, pid] = pid.compute(psi_d, psi_curr, r_current, u_curr, Fb, dt);
        
        res.delta(i) = delta_deg; res.F_jet(i) = F_jet;
        res.Delta(i) = D; res.k_i(i) = ki; res.F_bias(i) = Fb;
        
        [state, ~] = vsl.update(state, F_jet, delta_deg, dt);
        
        % --- SMART TERMINATION CHECK ---
        % Evaluates proximity to origin destination nodes to trigger clean loop breaks
        if strcmp(path.type, 'rectangle') || strcmp(path.type, 'circle')
            if (i*dt) > 40.0 && sqrt((x_curr - x_final)^2 + (y_curr - y_final)^2) < 3.5
                fprintf('  -> %s Path completed cleanly at destination origin.\n', type);
                break;
            end
        else
            if y_curr >= path.y_goal
                break;
            end
        end
        
        if any(abs(state(1:2)) > 1000) || isnan(state(1))
            break; 
        end
    end
end

%% --- Unified Path Reference Geometric Calculations ---
function [xr, yr, pr, nwp] = get_ref(path, x, y, cwp)
    nwp = cwp; xr = 0; yr = y; pr = pi/2;
    if strcmp(path.type, 'rectangle')
        WP = path.WP; 
        num_wp = size(WP, 1);
        
        p1 = WP(cwp-1, :); 
        p2 = WP(cwp, :);
        
        % CALIBRATED: Adjusted waypoint acceptance radius to 5.0m for realistic cornering
        if norm([x, y] - p2) < 5.0 && cwp < num_wp
            nwp = cwp + 1;
            p1 = WP(nwp-1, :);
            p2 = WP(nwp, :);
        end
        
        seg_vec = p2 - p1;
        seg_len = norm(seg_vec);
        if seg_len > 1e-4
            v2 = seg_vec / seg_len;
            proj_len = dot([x, y] - p1, v2);
            proj_len = max(0, min(seg_len, proj_len));
            proj = p1 + proj_len * v2;
            xr = proj(1); yr = proj(2);
            pr = atan2(seg_vec(2), seg_vec(1));
        else
            xr = p1(1); yr = p1(2); pr = 0;
        end
        
    elseif strcmp(path.type, 'circle')
        theta = atan2(y - path.yc, x - path.xc);
        xr = path.xc + path.R * cos(theta); 
        yr = path.yc + path.R * sin(theta);
        pr = wrapToPi(theta - pi/2); 
    end
end

%% --- Presentation Layer Plotting ---
function plot_single_trajectory(data, path, line_spec, t)
    hold on; grid on; box on;
    if strcmp(path.type,'rectangle')
        plot(path.WP(:,1), path.WP(:,2), 'k--', 'LineWidth', 1.5);
    elseif strcmp(path.type,'circle')
        th=0:0.05:2*pi; plot(path.xc+path.R*cos(th), path.yc+path.R*sin(th), 'k--', 'LineWidth', 1.5);
    else
        xline(0, 'k--', 'LineWidth', 1.5);
    end
    
    valid_idx = ~isnan(data.x);
    plot(data.x(valid_idx), data.y(valid_idx), line_spec, 'LineWidth', 2);
    
    last_idx = find(valid_idx, 1, 'last');
    plot(data.x(1), data.y(1), 'go', 'MarkerSize', 8, 'MarkerFaceColor', 'g');
    plot(data.x(last_idx), data.y(last_idx), 'rs', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
    
    xlabel('X Position [m]'); ylabel('Y Position [m]');
    axis equal;
end

function plot_error_comparison(rl, bl, t)
    hold on; grid on; box on;
    t_rl = t(1:length(rl.e));
    t_bl = t(1:length(bl.e));
    
    plot(t_rl, rl.e, 'b-', 'LineWidth', 1.5, 'DisplayName', 'DRL Tracker');
    plot(t_bl, bl.e, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Baseline ILOS');
    
    % FIXED: Set HandleVisibility to off to prevent the data1 legend artifact
    yline(0, 'k--', 'LineWidth', 1.2, 'HandleVisibility', 'off');
    
    xlabel('Time [s]'); ylabel('Cross-Track Error [m]');
    legend('Location', 'best', 'FontSize', 9);
end