classdef USVTrackingEnv < rl.env.MATLABEnvironment
    % USVTrackingEnv - Reinforcement Learning environment for USV path tracking
    % Trains DRL agent to tune ILOS parameters (Delta, k_i) and thrust bias
    
    properties
        % USV dynamics model
        USV
        
        % Heading controller
        Controller
        
        % State variables
        State           % [x, y, psi, u, v, r]
        e_int           % Integral of cross-track error
        
        % Path parameters
        x_path = 0;     % Path reference point x [m]
        y_path = 0;     % Path reference point y [m]
        chi_path = 0;   % Path course angle [rad]
        x_goal = 200;   % Goal x-coordinate [m]
        y_goal = 0;     % Goal y-coordinate [m]
        
        % Simulation parameters
        dt = 0.05;       % Time step [s]
        MaxTime = 120;  % Maximum episode time [s]
        CurrentTime = 0;% Current simulation time [s]
        
        % Reward parameters
        w_e = 10;       % Cross-track error weight
        w_psi = 2;      % Heading error weight
        w_delta = 0.3;  % Control effort weight
        steering_penalty_value = 5;  % Penalty for poor steering conditions
        bonus_coeff = 5;% Bonus coefficient for good tracking
        
        % Termination thresholds
        e_max = 20;     % Maximum cross-track error [m]
    end
    
    methods
        % Constructor - Initialize environment
        function this = USVTrackingEnv()
            
            % Define observation space (8 dimensions)
            ObservationInfo = rlNumericSpec([8 1]);
            ObservationInfo.Name = 'USV State Observations';
            ObservationInfo.Description = 'e, psi_error, e_int, u, v, r, kappa, dist_to_waypoint';
            ObservationInfo.LowerLimit = [-20; -pi; -inf; -2; -2; -pi; -1; 0];
            ObservationInfo.UpperLimit = [20; pi; inf; 5; 2; pi; 1; 300];
            
            % Define action space (3 continuous actions)
            % CALIBRATED: Bounds updated to match the standard plastic 40mm waterjet limits
            ActionInfo = rlNumericSpec([3 1]);
            ActionInfo.Name = 'ILOS and Thrust Parameters';
            ActionInfo.Description = 'Delta (lookahead), k_i (integral gain), F_bias (thrust)';
            ActionInfo.LowerLimit = [5;  0.001; 5.0];
            ActionInfo.UpperLimit = [50; 0.1;   24.5]; % Pinned exactly to USVModel's true absolute ceiling
            
            % Call superclass constructor
            this = this@rl.env.MATLABEnvironment(ObservationInfo, ActionInfo);
            
            % Initialize USV model
            this.USV = USVModel();
            
            % Initialize heading controller
            this.Controller = HeadingController();
            
            % Reset environment
            reset(this);
        end
        
        % STEP - Execute one time step in the environment
        function [Observation, Reward, IsDone, LoggedSignals] = step(this, Action)
            LoggedSignals = [];
            
            % Extract agent actions
            Delta = Action(1);      % Lookahead distance [m]
            k_i = Action(2);        % Integral gain
            F_bias = Action(3);     % Thrust bias [N]
            
            % Extract current state
            x = this.State(1);
            y = this.State(2);
            psi = this.State(3);
            u = this.State(4);
            v = this.State(5);
            r = this.State(6);
            
            % Call ILOS guidance law
            [psi_d, e, e_int_new] = ILOS_Guidance(x, y, psi, ...
                this.x_path, this.y_path, this.chi_path, ...
                this.e_int, Delta, k_i, this.dt);
            
            % Update integral state
            this.e_int = e_int_new;
            
            % Call heading controller
            [F_jet, delta, this.Controller] = this.Controller.compute(...
                psi_d, psi, r, u, F_bias, this.dt);
            
            % Check steerability constraint
            isDynamic = this.USV.checkSteerability(u, delta);
            if ~isDynamic
                % CALIBRATED: Changed emergency thrust override from 50N to a realistic 12N mid-range power band
                F_jet = 12.0;  
                delta = 0;   
            end
            
            % Step physics simulation
            [state_new, velocities] = this.USV.update(this.State, F_jet, delta, this.dt);
            this.State = state_new;
            
            % Update time
            this.CurrentTime = this.CurrentTime + this.dt;
            
            % Calculate heading error
            psi_error = wrapToPi(psi_d - psi);
            
            % Calculate reward
            Reward = this.computeReward(e, psi_error, delta, u);
            
            % Get observation
            Observation = this.getObservation();
            
            % Check termination conditions
            IsDone = this.checkTermination(e);
            
            % Log additional signals
            LoggedSignals.e = e;
            LoggedSignals.psi_error = psi_error;
            LoggedSignals.F_jet = F_jet;
            LoggedSignals.delta = delta;
            LoggedSignals.Delta = Delta;
            LoggedSignals.k_i = k_i;
            LoggedSignals.isDynamic = isDynamic;
        end
        
        % RESET - Reset environment to initial conditions
        function Observation = reset(this)
            
            % Randomize initial conditions for a VERTICAL path (|)
            x0 = -5 + 10 * rand();              % Uniform[-5, 5] (Random cross-track start)
            y0 = 0;                             % Start at bottom (Y=0)
            psi0 = deg2rad(90 - 20 + 40 * rand()); % Uniform[70°, 110°] (Facing mostly North)
            
            % Initial velocities (start with clean forward motion)
            u0 = 1.0;  % Initial surge velocity [m/s]
            v0 = 0;
            r0 = 0;
            
            % Initialize state
            this.State = [x0; y0; psi0; u0; v0; r0];
            
            % Reset integral
            this.e_int = 0;
            
            % Reset controller integral
            this.Controller = this.Controller.reset();
            
            % Reset time
            this.CurrentTime = 0;
            
            % Define reference path (Vertical line from (0,0) to (0,200))
            this.x_path = 0;
            this.y_path = 0;
            this.chi_path = pi/2;  % Due North (90 degrees in radians)
            this.x_goal = 0;
            this.y_goal = 200;
            
            % Get initial observation
            Observation = this.getObservation();
        end
        
        % GETOBSERVATION - Construct observation vector
        function Observation = getObservation(this)
            
            % Extract state
            x = this.State(1);
            y = this.State(2);
            psi = this.State(3);
            u = this.State(4);
            v = this.State(5);
            r = this.State(6);
            
            % Calculate cross-track error
            e = -(x - this.x_path) * sin(this.chi_path) + ...
                (y - this.y_path) * cos(this.chi_path);
            
            % Calculate heading error relative to path for observation vector
            psi_error = wrapToPi(this.chi_path - psi);
            
            % Path curvature (straight line = 0)
            kappa = 0;
            
            % Distance to waypoint
            dist_to_waypoint = sqrt((x - this.x_goal)^2 + (y - this.y_goal)^2);
            
            % Construct observation vector
            Observation = [
                e;              
                psi_error;      
                this.e_int;     
                u;              
                v;              
                r;              
                kappa;          
                dist_to_waypoint 
            ];
        end
        
        % COMPUTEREWARD - Calculate reward signal
        function Reward = computeReward(this, e, psi_error, delta, u)
            
            % Quadratic penalties
            tracking_penalty = -this.w_e * e^2;
            heading_penalty = -this.w_psi * psi_error^2;
            control_penalty = -this.w_delta * delta^2;
            
            % Steering penalty (low speed with high deflection)
            steering_penalty = 0;
            if u < 0.5 && abs(delta) > 15
                steering_penalty = -this.steering_penalty_value;
            end
            
            % Bonus for good tracking
            tracking_bonus = this.bonus_coeff * exp(-abs(e));
            
            % Total reward
            Reward = tracking_penalty + heading_penalty + control_penalty + ...
                     steering_penalty + tracking_bonus;
        end
        
        % CHECKTERMINATION - Check if episode should terminate
        function IsDone = checkTermination(this, e)
            
            % Terminate if cross-track error exceeds limit
            if abs(e) > this.e_max
                IsDone = true;
                return;
            end
            
            % Terminate if time limit exceeded
            if this.CurrentTime >= this.MaxTime
                IsDone = true;
                return;
            end
            
            IsDone = false;
        end
        
        % SETCURRENTDISTURBANCE - Add ocean current disturbance
        function setCurrentDisturbance(this, V_current, beta_current)
            this.USV = this.USV.setCurrentDisturbance(V_current, beta_current);
        end
        
        % VISUALIZEEPISODE - Run and visualize one debugging episode
        function visualizeEpisode(this, MaxSteps)
            if nargin < 2
                MaxSteps = 1000;
            end
            
            obs = reset(this);
            trajectory = zeros(MaxSteps, 2);
            e_history = zeros(MaxSteps, 1);
            reward_history = zeros(MaxSteps, 1);
            
            for step = 1:MaxSteps
                % Action limits mapped to new calibrated parameters
                action = [
                    5 + 45*rand();       % Delta [5, 50]
                    0.001 + 0.099*rand();% k_i [0.001, 0.1]
                    5.0 + 19.5*rand()    % F_bias scaled inside true [5.0, 24.5] window
                ];
                
                [obs, reward, done, logged] = step(this, action);
                
                trajectory(step, :) = this.State(1:2)';
                e_history(step) = logged.e;
                reward_history(step) = reward;
                
                if done
                    trajectory = trajectory(1:step, :);
                    e_history = e_history(1:step);
                    reward_history = reward_history(1:step);
                    break;
                end
            end
            
            figure('Position', [100, 100, 1200, 400]);
            
            subplot(1, 3, 1);
            plot(trajectory(:, 1), trajectory(:, 2), 'b-', 'LineWidth', 1.5);
            hold on;
            plot([0, this.x_goal], [0, this.y_goal], 'r--', 'LineWidth', 2);
            plot(0, 0, 'go', 'MarkerSize', 10, 'LineWidth', 2);
            plot(this.x_goal, this.y_goal, 'rx', 'MarkerSize', 10, 'LineWidth', 2);
            xlabel('X [m]'); ylabel('Y [m]');
            title('USV Trajectory');
            legend('Actual Path', 'Desired Path', 'Start', 'Goal');
            grid on; axis equal;
            
            subplot(1, 3, 2);
            time = (0:length(e_history)-1) * this.dt;
            plot(time, e_history, 'b-', 'LineWidth', 1.5);
            xlabel('Time [s]'); ylabel('Cross-track Error [m]');
            title('Tracking Error'); grid on;
            yline(this.e_max, 'r--', 'Max Error');
            yline(-this.e_max, 'r--');
            
            subplot(1, 3, 3);
            plot(time, cumsum(reward_history), 'b-', 'LineWidth', 1.5);
            xlabel('Time [s]'); ylabel('Cumulative Reward');
            title('Reward Evolution'); grid on;
        end
    end
end